VPS Hosting Panel (mini) - CodeSandbox Docker ready
--------------------------------------------------
This is a minimal VPS hosting panel that runs inside a Docker container.
Features:
- Create / Start / Stop / Restart / Delete container-based "VPS" (ubuntu:22.04, debian:13, alpine)
- Admin user and login system
- Admin settings (panel name)
- On first run the container will prompt to create an admin user (username, email, password)

How to run locally:
1. Build the image:
   docker build -t vpspanel .
2. Run the container (interactive prompt will appear if no admin exists):
   docker run -it -p 5000:5000 --privileged vpspanel
Note: --privileged or proper Docker socket access may be required for Docker-in-Docker.
