from flask import Flask, jsonify, request, session
from flask_cors import CORS
import docker, psutil, time
from models import init_db, SessionLocal, User, Setting
from passlib.hash import bcrypt
import os

init_db()
db = SessionLocal()
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY','devsecret')
CORS(app, supports_credentials=True)
client = docker.from_env()

# helper
def require_admin():
    user_id = session.get('user_id')
    if not user_id:
        return False
    user = db.query(User).filter(User.id==user_id).first()
    return user and user.is_admin

@app.route('/')
def home():
    panel_name = db.query(Setting).filter(Setting.key=='panel_name').first()
    name = panel_name.value if panel_name else 'VPS Panel'
    return jsonify({'status':'ok','panel_name': name})

# Auth
@app.route('/auth/login', methods=['POST'])
def login():
    data = request.json
    user = db.query(User).filter(User.username==data.get('username')).first()
    if not user or not bcrypt.verify(data.get('password',''), user.password):
        return jsonify({'ok':False,'msg':'Invalid credentials'}), 401
    session['user_id'] = user.id
    return jsonify({'ok':True,'is_admin':user.is_admin,'username':user.username})

@app.route('/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'ok':True})

# Admin: create user (admin only)
@app.route('/admin/create_user', methods=['POST'])
def create_user():
    if not require_admin():
        return jsonify({'ok':False,'msg':'admin only'}), 403
    data = request.json
    if db.query(User).filter(User.username==data.get('username')).first():
        return jsonify({'ok':False,'msg':'username exists'}), 400
    hashed = bcrypt.hash(data.get('password',''))
    user = User(username=data.get('username'), email=data.get('email'), password=hashed, is_admin=bool(data.get('is_admin',False)))
    db.add(user); db.commit()
    return jsonify({'ok':True})

# Settings
@app.route('/admin/settings', methods=['GET','POST'])
def admin_settings():
    if not require_admin():
        return jsonify({'ok':False,'msg':'admin only'}), 403
    if request.method=='GET':
        settings = db.query(Setting).all()
        return jsonify({s.key: s.value for s in settings})
    data = request.json
    for k,v in data.items():
        s = db.query(Setting).filter(Setting.key==k).first()
        if s:
            s.value = v
        else:
            s = Setting(key=k, value=v)
            db.add(s)
    db.commit()
    return jsonify({'ok':True})

# VPS endpoints
@app.route('/vps', methods=['GET'])
def list_vps():
    containers = client.containers.list(all=True)
    out = []
    for c in containers:
        out.append({
            'id': c.id[:12],
            'name': c.name,
            'status': c.status,
            'image': c.image.tags[0] if c.image.tags else 'unknown'
        })
    return jsonify(out)

@app.route('/vps/create', methods=['POST'])
def create_vps():
    if not require_admin():
        return jsonify({'ok':False,'msg':'admin only'}), 403
    data = request.json
    image = data.get('image','ubuntu:22.04')
    name = data.get('name', 'vps-'+image.replace(':','-'))
    ports = {'22/tcp': None}
    container = client.containers.run(image, name=name, detach=True, tty=True, stdin_open=True, ports=ports, command='/bin/bash')
    time.sleep(0.1)
    return jsonify({'ok':True,'id':container.id[:12]})

@app.route('/vps/<id>/action', methods=['POST'])
def vps_action(id):
    if not require_admin():
        return jsonify({'ok':False,'msg':'admin only'}), 403
    data = request.json
    action = data.get('action')
    try:
        container = client.containers.get(id)
    except Exception as e:
        return jsonify({'ok':False,'msg':'container not found'}), 404
    if action=='start':
        container.start()
    elif action=='stop':
        container.stop()
    elif action=='restart':
        container.restart()
    elif action=='delete':
        container.remove(force=True)
    return jsonify({'ok':True})

if __name__=='__main__':
    app.run(host='0.0.0.0', port=5000)
