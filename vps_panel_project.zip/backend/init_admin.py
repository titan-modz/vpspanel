# This script checks for any admin user. If none exists, it prompts the operator
# to create an admin (username, email, password). It's intended to run during container start.
import getpass
from models import init_db, SessionLocal, User
from passlib.hash import bcrypt
import sys

init_db()
db = SessionLocal()
admin = db.query(User).filter(User.is_admin == True).first()
if admin:
    print('Admin user exists. Skipping interactive setup.')
    sys.exit(0)

print('\n===== VPS Panel Admin Setup =====')
print('No admin user found. Create an admin account now.')
username = input('Admin username: ').strip()
email = input('Admin email: ').strip()
while True:
    password = getpass.getpass('Admin password: ')
    password2 = getpass.getpass('Confirm password: ')
    if password != password2:
        print('Passwords do not match. Try again.')
    elif len(password) < 6:
        print('Password too short (min 6).')
    else:
        break
hashed = bcrypt.hash(password)
user = User(username=username, email=email, password=hashed, is_admin=True)
db.add(user)
db.commit()
print('Admin account created. You can login via the frontend at /login')
