import React, {useState, useEffect} from 'react';

const API = process.env.REACT_APP_API || 'http://localhost:5000';

function Login({onLogin}) {
  const [u, setU] = useState(''); const [p, setP] = useState('');
  const submit = async () => {
    const res = await fetch(API + '/auth/login', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username:u,password:p}), credentials:'include'});
    const j = await res.json();
    if (j.ok) onLogin(j);
    else alert(j.msg || 'failed');
  };
  return <div style={{maxWidth:420,margin:'40px auto'}} className="glass">
    <h2>Login</h2>
    <input placeholder='username' value={u} onChange={e=>setU(e.target.value)} /><br/>
    <input placeholder='password' type='password' value={p} onChange={e=>setP(e.target.value)} /><br/>
    <button className='btn' onClick={submit}>Login</button>
  </div>;
}

function AdminPanel({user}) {
  const [vps, setVps] = useState([]);
  const [name, setName] = useState('');
  const load = async ()=>{ const r=await fetch(API + '/vps'); setVps(await r.json()); };
  useEffect(()=>{ load(); },[]);
  const create = async (image)=>{ await fetch(API+'/vps/create',{method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({image}), credentials:'include'}); load(); };
  const action = async (id,act)=>{ await fetch(API + '/vps/'+id+'/action',{method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:act}), credentials:'include'}); load(); };
  const saveSettings = async ()=>{ await fetch(API + '/admin/settings',{method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({panel_name:name}), credentials:'include'}); alert('saved'); };
  const loadSettings = async ()=>{ const r=await fetch(API + '/admin/settings', {credentials:'include'}); const j=await r.json(); setName(j.panel_name || 'VPS Panel'); };
  useEffect(()=>{ loadSettings(); },[]);
  return <div style={{padding:20}}>
    <h1>Admin Dashboard</h1>
    <div style={{display:'flex',gap:10, marginBottom:12}}>
      <button className='btn' onClick={()=>create('ubuntu:22.04')}>Create Ubuntu 22.04</button>
      <button className='btn' onClick={()=>create('debian:13')}>Create Debian 13</button>
      <button className='btn' onClick={()=>create('alpine:latest')}>Create Alpine</button>
    </div>

    <div className='glass' style={{marginBottom:12}}>
      <h3>Settings</h3>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder='Panel Name' />
      <button onClick={saveSettings} className='btn'>Save</button>
    </div>

    <div>
      <h3>VPS List</h3>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:12}}>
        {vps.map(v=>(
          <div key={v.id} className='glass'>
            <b>{v.name}</b>
            <div>Image: {v.image}</div>
            <div>Status: {v.status}</div>
            <div style={{marginTop:8}}>
              <button className='btn' onClick={()=>action(v.id,'start')}>Start</button>
              <button className='btn' onClick={()=>action(v.id,'stop')}>Stop</button>
              <button className='btn' onClick={()=>action(v.id,'restart')}>Restart</button>
              <button className='btn' onClick={()=>action(v.id,'delete')}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>;
}

export default function App(){
  const [user,setUser] = useState(null);
  return user ? <AdminPanel user={user} /> : <Login onLogin={setUser} />;
}
